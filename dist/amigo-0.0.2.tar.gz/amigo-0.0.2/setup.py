from setuptools import setup

setup(name='amigo',
      version='0.0.2',
      description='equlibrium tools',
      url='https://github.com/twistersi/Amigo',
      author='Simon McIntosh',
      author_email='simon.mcintosh@ukaea.uk',
      license='MIT',
      packages=['amigo'],
			zip_safe=False)
